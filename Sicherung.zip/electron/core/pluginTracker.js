function trackPluginEvent(Analytics, plugin, eventName, data = {}) {
  const payload = {
    plugin: plugin.name || "unknown",
    version: plugin.version || "unknown",
    ...data
  };

  Analytics.track(`plugin_${eventName}`, payload);
}

function trackPluginError(Analytics, plugin, error) {
  Analytics.track("plugin_error", {
    plugin: plugin.name || "unknown",
    version: plugin.version || "unknown",
    error: error.message || error
  });
}

module.exports = {
  trackPluginEvent,
  trackPluginError
};