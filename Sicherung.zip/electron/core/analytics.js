let sessionStart = null;
let sessionId = null;

const Analytics = (() => {

  function getCategory(eventName) {
  if (eventName.startsWith("ui_")) return "ui";
  if (eventName.startsWith("player_")) return "player";
  if (eventName.startsWith("system_")) return "system";
  if (eventName.startsWith("error_")) return "error";
  return "general";
}

function getLevel(eventName, data = {}) {
  // Manuelle Overrides haben Vorrang
  if (data.error) return "error";
  if (data.warning) return "warning";

  const name = eventName.toLowerCase();

  if (name.includes("error") || name.includes("fail")) return "error";
  if (name.includes("warn")) return "warning";
  if (name.includes("debug")) return "debug";

  return "info";
}

  function sanitize(value) {
    if (value === null || value === undefined) return undefined;
    if (typeof value === "string" && value.trim() === "") return "unknown";
    if (typeof value === "object") return JSON.stringify(value);
    return value;
  }

  function buildPayload(data) {
    const payload = {};
    for (const key in data) {
      const val = sanitize(data[key]);
      if (val !== undefined) payload[key] = val;
    }
    return payload;
  }

  function sendToAptabase(eventName, payload) {
    try {
      global.analytics?.trackEvent(eventName, payload);
    } catch (e) {
      console.error("[Aptabase]", e);
    }
  }

  function sendToSentry(level, eventName, payload) {
    try {
      if (!global.sentry) return;

      global.sentry.withScope(scope => {
        scope.setLevel(level);

        Object.entries(payload).forEach(([key, value]) => {
          scope.setExtra(key, value);
        });

        if (level === "error") {
          global.sentry.captureException(
            payload.error || new Error(eventName)
          );
        } else {
          global.sentry.captureMessage(eventName);
        }
      });

    } catch (e) {
      console.error("[Sentry]", e);
    }
  }

  function track(eventName, data = {}) {
    try {
      const level = getLevel(eventName, data);
      const category = getCategory(eventName);
      const session = Session.getSession();
      const payload = {
        ...buildPayload(data),
        category,
        sessionId: session.sessionId
      };

      sendToAptabase(eventName, payload);

      if (level === "warning" || level === "error") {
        sendToSentry(level, eventName, payload);
      }

      console.log(`[${category.toUpperCase()}][${level}]`, eventName, payload);

    } catch (err) {
      console.error("[CORE Analytics Error]", err);
    }
  }

  return { track };

})();

function generateSessionId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function startSession(Analytics) {
  sessionStart = Date.now();
  sessionId = generateSessionId();

  Analytics.track("system_session_start", {
    sessionId,
    timestamp: sessionStart
  });
}

function endSession(Analytics) {
  if (!sessionStart) return;

  const end = Date.now();
  const duration = end - sessionStart;

  Analytics.track("system_session_end", {
    sessionId,
    duration,
    startedAt: sessionStart,
    endedAt: end
  });
}

function getSession() {
  return {
    sessionId,
    sessionStart
  };
}

module.exports = {
  Analytics,
  startSession,
  endSession,
  getSession
};